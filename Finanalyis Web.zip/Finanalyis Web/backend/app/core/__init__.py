# Core configuration and utilities

